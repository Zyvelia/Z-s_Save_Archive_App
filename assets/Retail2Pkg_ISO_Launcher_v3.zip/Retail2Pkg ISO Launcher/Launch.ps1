Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Select-GameIso {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    try {
        $dialog.Title = 'Choose a PS3 game ISO'
        $dialog.Filter = 'ISO images (*.iso)|*.iso'
        $dialog.CheckFileExists = $true
        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            return $dialog.FileName
        }
    }
    finally {
        $dialog.Dispose()
    }
}

function Select-OutputFolder {
    param([string] $InitialFolder)

    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    try {
        $dialog.Description = 'Choose where to save the Retail2Pkg working folder and packages.'
        $dialog.SelectedPath = $InitialFolder
        $dialog.ShowNewFolderButton = $true
        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            return $dialog.SelectedPath
        }
    }
    finally {
        $dialog.Dispose()
    }
}

function Assert-RuntimeInstalled {
    param([string] $ToolsFolder)

    $x86SystemFolder = if ([Environment]::Is64BitOperatingSystem) {
        Join-Path $env:SystemRoot 'SysWOW64'
    }
    else {
        Join-Path $env:SystemRoot 'System32'
    }

    if ((Test-Path -LiteralPath (Join-Path $x86SystemFolder 'MSVCR120.dll') -PathType Leaf) -or
        (Test-Path -LiteralPath (Join-Path $ToolsFolder 'MSVCR120.dll') -PathType Leaf)) {
        return
    }

    $downloadPage = 'https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist#visual-studio-2013-vc-120'
    Write-Host 'Install the Microsoft Visual C++ 2013 Redistributable (x86) to supply MSVCR120.dll.'
    Write-Host 'Use the x86 package even on 64-bit Windows.'
    Write-Host $downloadPage
    if ((Read-Host 'Open the Microsoft downloads page? [y/N]') -eq 'y') {
        Start-Process -FilePath $downloadPage
    }
    throw 'Install vcredist_x86.exe from the Visual Studio 2013 section, then start the launcher again.'
}

function Get-IsoGameFolder {
    param($Image)

    for ($attempt = 0; $attempt -lt 12; $attempt++) {
        foreach ($volume in @($Image | Get-Volume -ErrorAction SilentlyContinue)) {
            if ($volume.DriveLetter) {
                $candidate = '{0}:\PS3_GAME' -f $volume.DriveLetter
                if (Test-Path -LiteralPath $candidate -PathType Container) {
                    return $candidate
                }
            }
        }
        if ($attempt -lt 11) {
            Start-Sleep -Milliseconds 500
        }
    }

    throw 'Windows could not read a PS3_GAME folder at the root of the image. Choose a readable, decrypted PS3 game ISO.'
}

function Assert-GameFolder {
    param([string] $GameFolder)

    $sfoPath = Join-Path $GameFolder 'PARAM.SFO'
    $userData = Join-Path $GameFolder 'USRDIR'
    if (!(Test-Path -LiteralPath $sfoPath -PathType Leaf) -or
        !(Test-Path -LiteralPath $userData -PathType Container)) {
        throw 'The PS3_GAME folder must contain PARAM.SFO and USRDIR.'
    }

    $file = [IO.File]::OpenRead($sfoPath)
    try {
        $header = New-Object byte[] 4
        $bytesRead = $file.Read($header, 0, $header.Length)
        if ($bytesRead -ne 4 -or [BitConverter]::ToString($header) -ne '00-50-53-46') {
            throw 'PARAM.SFO is unreadable. Choose a decrypted PS3 game ISO with a valid PARAM.SFO.'
        }
    }
    finally {
        $file.Dispose()
    }
}

function Copy-GameFromIso {
    param(
        [string] $IsoPath,
        [string] $ToolsFolder,
        [string] $RunFolder
    )

    $mountedByLauncher = $false
    try {
        Write-Host 'Mounting the ISO...'
        $image = Get-DiskImage -ImagePath $IsoPath
        if (!$image.Attached) {
            $image = Mount-DiskImage -ImagePath $IsoPath -Access ReadOnly -PassThru
            $mountedByLauncher = $true
        }

        $gameFolder = Get-IsoGameFolder -Image $image
        Assert-GameFolder -GameFolder $gameFolder

        [IO.Directory]::CreateDirectory($RunFolder) | Out-Null
        foreach ($tool in Get-ChildItem -LiteralPath $ToolsFolder -Force) {
            Copy-Item -LiteralPath $tool.FullName -Destination $RunFolder -Recurse -Force
        }

        Write-Host 'Extracting PS3_GAME. Large games may take several minutes.'
        $target = Join-Path $RunFolder 'PS3_GAME'
        $robocopy = Join-Path $env:SystemRoot 'System32\robocopy.exe'
        & $robocopy $gameFolder $target /E /COPY:DT /DCOPY:DT /A-:R /XJ /R:1 /W:1 /NP /NFL /NDL
        if ($LASTEXITCODE -ge 8) {
            throw ('PS3_GAME could not be copied. Robocopy returned {0}. Check the output drive and free space.' -f $LASTEXITCODE)
        }
        Get-ChildItem -LiteralPath $target -Recurse -File -Force |
            Where-Object { $_.IsReadOnly } |
            ForEach-Object { $_.IsReadOnly = $false }
        Assert-GameFolder -GameFolder $target
    }
    finally {
        if ($mountedByLauncher) {
            try {
                Dismount-DiskImage -ImagePath $IsoPath | Out-Null
            }
            catch {
                Write-Warning ('Could not eject the ISO. You can eject it in File Explorer. {0}' -f $_.Exception.Message)
            }
        }
    }
}

function Invoke-Retail2Pkg {
    param([string] $RunFolder)

    Write-Host
    Write-Host 'Running Retail2Pkg.bat. Follow any prompts from the converter.'
    Write-Host ('If PS3Merge opens, select this folder: {0}' -f $RunFolder)

    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = Join-Path $env:SystemRoot 'System32\cmd.exe'
    $startInfo.Arguments = '/d /v:off /c Retail2Pkg.bat /launcher'
    $startInfo.WorkingDirectory = $RunFolder
    $startInfo.UseShellExecute = $false
    $process = [System.Diagnostics.Process]::Start($startInfo)
    try {
        $process.WaitForExit()
        if ($process.ExitCode -ne 0) {
            throw ('Retail2Pkg stopped (exit code {0}). Check the converter messages above.' -f $process.ExitCode)
        }
    }
    finally {
        $process.Dispose()
    }
}

function Get-ConvertedPackages {
    param([string] $RunFolder)

    foreach ($folder in Get-ChildItem -LiteralPath $RunFolder -Directory) {
        $pkgByName = @{}
        foreach ($file in Get-ChildItem -LiteralPath $folder.FullName -Filter '*.pkg' -File) {
            if ($file.Length -gt 0) { $pkgByName[$file.BaseName] = $file }
        }

        $game = $folder.Name
        $update = $game + '_-_Update'
        $fix = $game + '_-_Fix'
        if ($pkgByName.ContainsKey($game) -and $pkgByName.ContainsKey($update)) {
            $pkgByName[$game]
            $pkgByName[$update]
            if ($pkgByName.ContainsKey($fix)) { $pkgByName[$fix] }
            return
        }
    }
    throw 'The converter did not leave both expected package files. Check its messages above.'
}

$runFolder = $null
try {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.Application]::EnableVisualStyles()
    Write-Host 'Retail2Pkg ISO Launcher'

    $toolsFolder = Join-Path $PSScriptRoot 'Retail2Pkg'
    if (!(Test-Path -LiteralPath (Join-Path $toolsFolder 'Retail2Pkg.bat') -PathType Leaf)) {
        throw 'Retail2Pkg.bat is missing. Extract the entire ZIP before opening Start.cmd.'
    }
    Assert-RuntimeInstalled -ToolsFolder $toolsFolder

    $isoPath = Select-GameIso
    if (!$isoPath) { exit 0 }

    $outputFolder = Select-OutputFolder -InitialFolder ([IO.Path]::GetDirectoryName($isoPath))
    if (!$outputFolder) { exit 0 }

    if ($outputFolder.StartsWith('\\')) {
        throw 'Choose an output folder on a local drive so the legacy batch file can use it.'
    }

    $isoName = [IO.Path]::GetFileNameWithoutExtension($isoPath)
    if ($isoName.Length -gt 32) { $isoName = $isoName.Substring(0, 32).TrimEnd() }
    $runName = 'R2P {0} {1}' -f $isoName, [Guid]::NewGuid().ToString('N').Substring(0, 8)
    $runFolder = Join-Path $outputFolder $runName

    Copy-GameFromIso -IsoPath $isoPath -ToolsFolder $toolsFolder -RunFolder $runFolder
    Invoke-Retail2Pkg -RunFolder $runFolder

    $packages = @(Get-ConvertedPackages -RunFolder $runFolder)

    Write-Host
    Write-Host 'Created packages:' -ForegroundColor Green
    foreach ($package in $packages) {
        Write-Host $package.FullName
    }
    try {
        Invoke-Item -LiteralPath $packages[0].DirectoryName
    }
    catch {
        Write-Warning 'Open the package folder using the paths shown above.'
    }
}
catch {
    Write-Host
    Write-Host $_.Exception.Message -ForegroundColor Red
    if ($runFolder -and (Test-Path -LiteralPath $runFolder -PathType Container)) {
        Write-Host ('Working files were saved in {0}' -f $runFolder)
    }
    exit 1
}
