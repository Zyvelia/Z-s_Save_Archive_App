Retail2Pkg ISO Launcher for Windows 10 and 11

1. Extract the entire ZIP. Open Start.cmd.
2. Select a readable, decrypted PS3 game ISO.
3. Choose an output folder on a local drive. It needs space for the
   extracted game, conversion files, and packages. Use NTFS or exFAT
   if a game or package contains a file larger than 4 GB.
4. Follow the prompts in the Retail2Pkg console. If PS3Merge opens,
   select the working folder shown in the console.
5. When the converter succeeds, the launcher lists the .pkg files and
   opens their folder. Each run has its own working folder inside the
   location you chose. It can still contain large intermediate files.

If you get the MSVCR120.dll error, install or repair the Visual C++ 2013
Redistributable (x86), even on 64-bit Windows. Get vcredist_x86.exe from
the Visual Studio 2013 section of Microsoft's downloads page:
https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist#visual-studio-2013-vc-120

The launcher mounts the ISO read-only using Windows, copies PS3_GAME,
and runs the included Retail2Pkg.bat. Conversion depends on the
included helper's support for your game and may need an internet
connection to obtain a game update.
